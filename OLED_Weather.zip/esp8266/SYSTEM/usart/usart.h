#ifndef __USART_H
#define __USART_H 
#include "sys.h"
#include "stdio.h"	  

#define EN_USART2_RX 			0		//ʹ�ܣ�1��/��ֹ��0������1����
	  	
void uart2_init(u32 pclk2,u32 bound); 
void uart1_init(u32 pclk2,u32 bound);

void USART1_SendString(u8 *p);
void USART2_SendString(u8 *p);

void USART1_SendByte(u8 p);
void USART2_SendByte(u8 p);
extern u8 TianQi[1000];

void TianQiTiQu();
#endif	   
















