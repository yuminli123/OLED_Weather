#ifndef __ESP8266_H
#define __ESP8266_H 

void Esp8266_Connect(void);
void Quest(void);

#endif



