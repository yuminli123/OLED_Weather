#include "esp8266.h"
#include "usart.h"
#include "delay.h"


void Esp8266_Connect(void)
{
  USART2_SendString("AT\r\n");
	delay_ms(500);
  USART2_SendString("AT+CWMODE=1\r\n");
	delay_ms(500);
	USART2_SendString("AT+RST\r\n");
	delay_ms(500);
	USART2_SendString("AT+CWJAP=\"iPhone\",\"99999999\"\r\n");
	delay_ms(5000);
	USART2_SendString("AT+CIPSTART=\"TCP\",\"api.seniverse.com\",80\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPMODE=1\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPSEND\r\n");
	delay_ms(500);
	USART2_SendString("GET https://api.seniverse.com/v3/weather/now.json?key=SPkcvTDnvRLImt80c&location=zibo&language=en&unit=c\r\n");
	delay_ms(500);
	USART2_SendString("+++");
	delay_ms(2000);
	USART2_SendString("AT+CIPMODE=0\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPCLOSE\r\n");
}
  
void Quest(void)
{
	
	USART2_SendString("AT+CIPSTART=\"TCP\",\"api.seniverse.com\",80\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPMODE=1\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPSEND\r\n");
	delay_ms(500);
	USART2_SendString("GET https://api.seniverse.com/v3/weather/now.json?key=SPkcvTDnvRLImt80c&location=zibo&language=en&unit=c\r\n");
	delay_ms(500);
	USART2_SendString("+++");
	delay_ms(2000);
	USART2_SendString("AT+CIPMODE=0\r\n");
	delay_ms(500);
	USART2_SendString("AT+CIPCLOSE\r\n");
	
}



